# 🇩🇿 Bot de Surveillance des Créneaux TCF SO / DAP - Alger

Ce bot vérifie automatiquement les créneaux disponibles pour les tests **TCF SO** et **TCF DAP** sur le site de l’Institut Français d’Algérie.

## 🚀 Fonctionnement
- Scrute régulièrement la page de réservation (`https://reservation.if-algerie.com/`)
- Envoie une notification sur **Telegram** dès qu’un créneau est disponible

## ⚙️ Configuration
1. Ouvre le fichier `main.py`
2. Remplace la ligne :
   ```python
   TOKEN = "TON_TOKEN_ICI"
   ```
   par ton vrai token Telegram.

3. Déploie le projet sur [Render.com](https://render.com) ou [Replit](https://replit.com)

### Commandes Render
- **Build Command** : `pip install -r requirements.txt`
- **Start Command** : `python main.py`

## 💬 Auteur
Créé avec ❤️ pour aider à surveiller les créneaux TCF à Alger.
