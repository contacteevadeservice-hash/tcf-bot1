import requests
import time
from bs4 import BeautifulSoup
from flask import Flask

TOKEN = "TON_TOKEN_ICI"
CHAT_ID = "8441574204"
URL = "https://reservation.if-algerie.com/"
INTERVAL = 300

app = Flask(__name__)

@app.route('/')
def home():
    return "Bot TCF/DAP Actif ✅"

def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    params = {"chat_id": CHAT_ID, "text": text}
    requests.get(url, params=params)

def check_tcf_slots():
    try:
        r = requests.get(URL, timeout=20)
        soup = BeautifulSoup(r.text, "html.parser")
        text = soup.get_text().lower()

        found = False
        if "tcf so" in text:
            send_telegram_message("⚠️ Créneau disponible pour TCF SO à Alger ! 🔗 " + URL)
            found = True
        if "tcf dap" in text:
            send_telegram_message("⚠️ Créneau disponible pour TCF DAP à Alger ! 🔗 " + URL)
            found = True

        if found:
            print("✅ Créneau trouvé ! Notification envoyée.")
        else:
            print("⏳ Aucun créneau pour le moment...")

    except Exception as e:
        print("Erreur :", e)

if __name__ == "__main__":
    send_telegram_message("🚀 Surveillance TCF SO / DAP activée sur " + URL)
    import threading
    def loop_check():
        while True:
            check_tcf_slots()
            time.sleep(INTERVAL)
    threading.Thread(target=loop_check).start()
    app.run(host='0.0.0.0', port=10000)
